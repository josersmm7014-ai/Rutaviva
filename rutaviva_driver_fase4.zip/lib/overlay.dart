import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'capture.dart';
import 'models.dart';
import 'ocr.dart';
import 'store.dart';

/// Lado de la app principal: abre/cierra la burbuja, le envía datos y
/// atiende el botón CALCULAR (captura + lectura + veredicto).
class OverlayCtrl {
  static bool _listening = false;
  static bool _busy = false;

  /// Llamar una vez al iniciar la app.
  static void init() {
    if (_listening) return;
    _listening = true;
    store.addListener(push);
    FlutterOverlayWindow.overlayListener.listen((event) {
      if (event == 'toggleHome') {
        store.toggleHomeMode();
      } else if (event == 'ready') {
        push();
      } else if (event == 'capture') {
        _handleCapture();
      }
    });
  }

  static Future<bool> isActive() => FlutterOverlayWindow.isActive();

  /// Pide el permiso de dibujar sobre otras apps y abre la burbuja.
  static Future<bool> start() async {
    var ok = await FlutterOverlayWindow.isPermissionGranted();
    if (!ok) {
      ok = (await FlutterOverlayWindow.requestPermission()) ?? false;
    }
    if (!ok) return false;
    if (!await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'RutaViva',
        overlayContent: 'Burbuja activa',
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        height: 480,
        width: 640,
      );
    }
    Future.delayed(const Duration(milliseconds: 800), push);
    return true;
  }

  static Future<void> stop() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
    }
  }

  static Future<void> _send(Map<String, dynamic> data) async {
    try {
      if (!await FlutterOverlayWindow.isActive()) return;
      await FlutterOverlayWindow.shareData(jsonEncode(data));
    } catch (_) {
      // Si la burbuja no está lista, se reintenta en el próximo cambio.
    }
  }

  static Future<void> push() async {
    final trips = store.todayTrips;
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final kmPass = trips.fold<double>(0, (s, t) => s + t.km);
    final kmEmpty =
        trips.fold<double>(0, (s, t) => s + (t.returnEmpty ? t.km : 0));
    await _send({
      'net': net,
      'perHour': hours > 0 ? net / hours : 0.0,
      'kmPass': kmPass,
      'kmEmpty': kmEmpty,
      'homeMode': store.homeMode,
    });
  }

  /// Toma la pantalla, lee precio/km/minutos y manda el veredicto a la burbuja.
  static Future<void> _handleCapture() async {
    if (_busy) return;
    _busy = true;
    try {
      // Espera a que la burbuja se oculte de la captura.
      await Future<void>.delayed(const Duration(milliseconds: 450));
      final path = await Capture.capture();
      if (path == null) {
        await _send({
          'state': 'error',
          'msg': 'La captura no está activa. Abre RutaViva y vuelve a activar el modo flotante.',
        });
        return;
      }
      final r = await readScreenshot(path);
      final v = store.vehicle;
      if (v == null || r.price == null || r.km == null || r.minutes == null) {
        final found = <String>[
          if (r.price != null) 'precio',
          if (r.km != null) 'km',
          if (r.minutes != null) 'minutos',
        ];
        await _send({
          'state': 'error',
          'msg': found.isEmpty
              ? 'No pude leer el viaje en la pantalla'
              : 'Solo pude leer: ${found.join(', ')}',
        });
        return;
      }
      final trip = Trip(
        id: 'tmp',
        date: DateTime.now(),
        origin: '',
        destination: '',
        price: r.price!,
        km: r.km!,
        minutes: r.minutes!,
        returnEmpty: true,
        fuelCost: v.fuelCostFor(r.km! * 2),
      );
      await _send({
        'state': 'result',
        'verdict': trip.verdict,
        'perHour': trip.perHour,
        'net': trip.net,
        'price': trip.price,
        'km': trip.km,
        'minutes': trip.minutes,
      });
    } catch (_) {
      await _send({'state': 'error', 'msg': 'Error al calcular el viaje'});
    } finally {
      _busy = false;
    }
  }
}

/// Lado de la burbuja (corre en su propio proceso de Flutter).
class OverlayBubble extends StatefulWidget {
  const OverlayBubble({super.key});

  @override
  State<OverlayBubble> createState() => _OverlayBubbleState();
}

enum _Mode { idle, loading, result, error }

class _OverlayBubbleState extends State<OverlayBubble> {
  double net = 0;
  double perHour = 0;
  double kmPass = 0;
  double kmEmpty = 0;
  bool homeMode = false;

  _Mode mode = _Mode.idle;
  String verdict = '';
  double rPerHour = 0;
  double rNet = 0;
  double rPrice = 0;
  double rKm = 0;
  double rMin = 0;
  String errorMsg = '';
  Timer? _timer;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FlutterOverlayWindow.overlayListener.listen(_onData);
    FlutterOverlayWindow.shareData('ready');
  }

  void _onData(dynamic event) {
    try {
      final m = jsonDecode('$event') as Map<String, dynamic>;
      if (m.containsKey('state')) {
        final st = m['state'] as String;
        if (st == 'result') {
          setState(() {
            mode = _Mode.result;
            verdict = m['verdict'] as String;
            rPerHour = (m['perHour'] as num).toDouble();
            rNet = (m['net'] as num).toDouble();
            rPrice = (m['price'] as num).toDouble();
            rKm = (m['km'] as num).toDouble();
            rMin = (m['minutes'] as num).toDouble();
          });
          _backToIdleIn(12);
        } else {
          setState(() {
            mode = _Mode.error;
            errorMsg = (m['msg'] as String?) ?? 'Error';
          });
          _backToIdleIn(7);
        }
        return;
      }
      setState(() {
        net = (m['net'] as num).toDouble();
        perHour = (m['perHour'] as num).toDouble();
        kmPass = (m['kmPass'] as num).toDouble();
        kmEmpty = (m['kmEmpty'] as num).toDouble();
        homeMode = m['homeMode'] as bool;
      });
    } catch (_) {}
  }

  void _backToIdleIn(int seconds) {
    _timer?.cancel();
    _timer = Timer(Duration(seconds: seconds), () {
      if (mounted) setState(() => mode = _Mode.idle);
    });
  }

  void _calculate() {
    _timer?.cancel();
    // Primero se oculta todo texto con dólares para que no salga en la captura.
    setState(() => mode = _Mode.loading);
    FlutterOverlayWindow.shareData('capture');
    _backToIdleIn(15);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _sub?.cancel();
    super.dispose();
  }

  String _m(double v) => '\$${v.toStringAsFixed(2)}';

  Color _color(String v) {
    if (v == 'CONVIENE') return const Color(0xFF1B8E5A);
    if (v == 'DUDOSO') return const Color(0xFFE0A100);
    return const Color(0xFFC62828);
  }

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF1B8E5A);
    Widget body;
    Color border = green;

    if (mode == _Mode.loading) {
      body = const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 3),
            ),
            SizedBox(height: 10),
            Text('Calculando…', style: TextStyle(color: Colors.white, fontSize: 16)),
          ],
        ),
      );
    } else if (mode == _Mode.result) {
      border = _color(verdict);
      body = GestureDetector(
        onTap: () => setState(() => mode = _Mode.idle),
        child: Container(
          decoration: BoxDecoration(
            color: _color(verdict),
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.all(10),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  verdict,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold),
                ),
                Text('${_m(rPerHour)} por hora',
                    style: const TextStyle(color: Colors.white, fontSize: 20)),
                Text('Neto ${_m(rNet)} de ${_m(rPrice)}',
                    style: const TextStyle(color: Colors.white, fontSize: 14)),
                Text('${rKm.toStringAsFixed(1)} km · ${rMin.toStringAsFixed(0)} min (con regreso vacío)',
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 4),
                const Text('Toca para cerrar',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
        ),
      );
    } else if (mode == _Mode.error) {
      border = Colors.orange;
      body = GestureDetector(
        onTap: () => setState(() => mode = _Mode.idle),
        child: Center(
          child: Text(
            errorMsg,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
      );
    } else {
      body = Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Neto hoy: ${_m(net)}',
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
          Text('${_m(perHour)} por hora · ${kmPass.toStringAsFixed(1)} km con pasajero · ${kmEmpty.toStringAsFixed(1)} vacíos',
              style: const TextStyle(color: Colors.white70, fontSize: 11)),
          const SizedBox(height: 8),
          SizedBox(
            height: 52,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: green,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: _calculate,
              child: const Text('CALCULAR',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 6),
          SizedBox(
            height: 32,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: homeMode ? green : Colors.grey.shade800,
                padding: EdgeInsets.zero,
              ),
              onPressed: () => FlutterOverlayWindow.shareData('toggleHome'),
              child: Text(
                homeMode ? 'Hacia casa: ACTIVO' : 'Hacia casa',
                style: const TextStyle(fontSize: 13),
              ),
            ),
          ),
        ],
      );
    }

    return Material(
      color: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xEE101614),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border, width: 2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'RutaViva',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
                GestureDetector(
                  onTap: () => FlutterOverlayWindow.closeOverlay(),
                  child: const Icon(Icons.close, color: Colors.white70, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(child: body),
          ],
        ),
      ),
    );
  }
}
