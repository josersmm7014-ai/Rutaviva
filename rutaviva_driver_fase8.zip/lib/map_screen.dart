import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'geo.dart';
import 'store.dart';

class _Zone {
  final String name;
  final LatLng center;
  final double perKm;
  final double radius; // metros

  const _Zone(this.name, this.center, this.perKm, this.radius);
}

// Datos simulados de ejemplo ($ por km). Los reales llegan con el servidor.
const List<_Zone> _zones = [
  _Zone('San Salvador', LatLng(13.6929, -89.2182), 0.45, 4500),
  _Zone('Santa Tecla', LatLng(13.6769, -89.2797), 0.62, 3500),
  _Zone('Soyapango', LatLng(13.7102, -89.1394), 0.30, 3500),
  _Zone('Apopa', LatLng(13.8069, -89.1792), 0.22, 3500),
];

Color _zoneColor(double v) {
  if (v >= 0.60) return const Color(0xFF0B5D36);
  if (v >= 0.40) return const Color(0xFF6BBF59);
  if (v >= 0.25) return const Color(0xFFE0A100);
  return const Color(0xFFC62828);
}

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController controller = MapController();
  LatLng? me;
  bool loading = false;

  Future<void> _locate() async {
    setState(() => loading = true);
    try {
      final p = await currentLatLng();
      if (!mounted) return;
      if (p == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Activa la ubicación y da el permiso')),
        );
        return;
      }
      setState(() => me = p);
      controller.move(p, 14);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No pude obtener tu ubicación')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final home = store.hasHome ? LatLng(store.homeLat!, store.homeLon!) : null;
    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            mapController: controller,
            options: const MapOptions(
              initialCenter: LatLng(13.72, -89.2),
              initialZoom: 11,
              interactionOptions: InteractionOptions(
                flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
              ),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.rutaviva.rutaviva',
              ),
              CircleLayer(
                circles: [
                  for (final z in _zones)
                    CircleMarker(
                      point: z.center,
                      radius: z.radius,
                      useRadiusInMeter: true,
                      color: _zoneColor(z.perKm).withAlpha(90),
                      borderColor: _zoneColor(z.perKm),
                      borderStrokeWidth: 2,
                    ),
                ],
              ),
              MarkerLayer(
                markers: [
                  for (final z in _zones)
                    Marker(
                      point: z.center,
                      width: 110,
                      height: 44,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${z.name}\n\$${z.perKm.toStringAsFixed(2)}/km',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 11),
                        ),
                      ),
                    ),
                  if (home != null)
                    Marker(
                      point: home,
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.home, color: Colors.orange, size: 34),
                    ),
                  if (me != null)
                    Marker(
                      point: me!,
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.my_location, color: Colors.blue, size: 34),
                    ),
                ],
              ),
            ],
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'Mapa de calor (datos de ejemplo)',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Verde oscuro \$0.60+/km · verde claro \$0.40 · amarillo \$0.25 · rojo menos',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: loading ? null : _locate,
        icon: loading
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.my_location),
        label: const Text('Mi ubicación'),
      ),
    );
  }
}
