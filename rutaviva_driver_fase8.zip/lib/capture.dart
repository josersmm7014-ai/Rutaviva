import 'package:flutter/services.dart';

/// Puente con el código Android que captura la pantalla (MediaProjection).
class Capture {
  static const MethodChannel _ch = MethodChannel('rutaviva/capture');

  /// Muestra el permiso del sistema y arranca la captura.
  static Future<bool> start() async {
    try {
      final ok = await _ch.invokeMethod<bool>('start') ?? false;
      if (ok) await Future<void>.delayed(const Duration(milliseconds: 800));
      return ok;
    } catch (_) {
      return false;
    }
  }

  /// Guarda la pantalla actual y devuelve la ruta de la imagen.
  static Future<String?> capture() async {
    try {
      return await _ch.invokeMethod<String>('capture');
    } catch (_) {
      return null;
    }
  }

  static Future<bool> isActive() async {
    try {
      return await _ch.invokeMethod<bool>('isActive') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> stop() async {
    try {
      await _ch.invokeMethod<bool>('stop');
    } catch (_) {}
  }
}
