import 'dart:convert';
import 'dart:math';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' show LatLng;

class GeoPoint {
  final double lat;
  final double lon;
  const GeoPoint(this.lat, this.lon);

  LatLng get ll => LatLng(lat, lon);
}

class RouteInfo {
  final double km;
  final double minutes; // sin tráfico
  final List<LatLng> points;
  const RouteInfo(this.km, this.minutes, this.points);
}

/// Busca una dirección en El Salvador con Nominatim (OpenStreetMap).
Future<GeoPoint?> geocode(String query) async {
  final q = query.trim();
  if (q.isEmpty) return null;
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'q': '$q, El Salvador',
    'format': 'json',
    'limit': '1',
    'countrycodes': 'sv',
  });
  final res = await http
      .get(uri, headers: {'User-Agent': 'RutaNeta/1.0'})
      .timeout(const Duration(seconds: 12));
  if (res.statusCode != 200) return null;
  final list = jsonDecode(res.body) as List;
  if (list.isEmpty) return null;
  final m = list.first as Map<String, dynamic>;
  final lat = double.tryParse('${m['lat']}');
  final lon = double.tryParse('${m['lon']}');
  if (lat == null || lon == null) return null;
  return GeoPoint(lat, lon);
}

/// Distancia, tiempo y trazo de la ruta por carretera con OSRM (sin tráfico).
Future<RouteInfo?> drivingRoute(GeoPoint a, GeoPoint b) async {
  final uri = Uri.parse(
    'https://router.project-osrm.org/route/v1/driving/'
    '${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 15));
  if (res.statusCode != 200) return null;
  final j = jsonDecode(res.body) as Map<String, dynamic>;
  final routes = j['routes'] as List?;
  if (routes == null || routes.isEmpty) return null;
  final r = routes.first as Map<String, dynamic>;
  final meters = (r['distance'] as num).toDouble();
  final seconds = (r['duration'] as num).toDouble();
  final points = <LatLng>[];
  final geometry = r['geometry'] as Map<String, dynamic>?;
  final coords = geometry?['coordinates'] as List?;
  if (coords != null) {
    for (final c in coords) {
      final pair = c as List;
      points.add(LatLng((pair[1] as num).toDouble(), (pair[0] as num).toDouble()));
    }
  }
  return RouteInfo(meters / 1000, seconds / 60, points);
}

/// Posición actual del teléfono, o null si no hay permiso o GPS apagado.
Future<LatLng?> currentLatLng() async {
  if (!await Geolocator.isLocationServiceEnabled()) return null;
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied ||
      perm == LocationPermission.deniedForever) {
    return null;
  }
  final pos = await Geolocator.getCurrentPosition();
  return LatLng(pos.latitude, pos.longitude);
}

double haversineKm(GeoPoint a, GeoPoint b) {
  const r = 6371.0;
  double rad(double d) => d * pi / 180;
  final dLat = rad(b.lat - a.lat);
  final dLon = rad(b.lon - a.lon);
  final h = pow(sin(dLat / 2), 2) +
      cos(rad(a.lat)) * cos(rad(b.lat)) * pow(sin(dLon / 2), 2);
  return 2 * r * asin(sqrt(h));
}
