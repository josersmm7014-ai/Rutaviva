import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;

/// Aparece deslizando y con fundido; el índice escalona la entrada.
class FadeSlideIn extends StatelessWidget {
  final int index;
  final Widget child;

  const FadeSlideIn({super.key, required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + index * 120),
      curve: Curves.easeOutCubic,
      builder: (context, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * 24), child: child),
      ),
      child: child,
    );
  }
}

/// Número en dólares que cuenta hasta su valor.
class AnimatedMoney extends StatelessWidget {
  final double value;
  final TextStyle? style;
  final String suffix;

  const AnimatedMoney({
    super.key,
    required this.value,
    this.style,
    this.suffix = '',
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value),
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) =>
          Text('\$${v.toStringAsFixed(2)}$suffix', style: style),
    );
  }
}

/// Anillo de progreso animado (meta diaria).
class GoalRing extends StatelessWidget {
  final double progress;
  final double size;
  final Widget child;

  const GoalRing({
    super.key,
    required this.progress,
    required this.size,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    final p = progress.clamp(0.0, 1.0).toDouble();
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: p),
      duration: const Duration(milliseconds: 1000),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _RingPainter(v, color),
          child: Center(child: child),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double p;
  final Color color;

  _RingPainter(this.p, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    const stroke = 10.0;
    final rect = Rect.fromLTWH(
      stroke / 2,
      stroke / 2,
      size.width - stroke,
      size.height - stroke,
    );
    final bg = Paint()
      ..color = Colors.white24
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    final fg = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, 0, math.pi * 2, false, bg);
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * p, false, fg);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.p != p || old.color != color;
}

/// Hace "respirar" a su hijo (botón principal).
class PulseButton extends StatefulWidget {
  final Widget child;

  const PulseButton({super.key, required this.child});

  @override
  State<PulseButton> createState() => _PulseButtonState();
}

class _PulseButtonState extends State<PulseButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: Tween<double>(begin: 1.0, end: 1.03).animate(
        CurvedAnimation(parent: _c, curve: Curves.easeInOut),
      ),
      child: widget.child,
    );
  }
}

/// Barra de rojo a verde que ubica los dólares por hora.
class HourBar extends StatelessWidget {
  final double perHour;

  const HourBar({super.key, required this.perHour});

  @override
  Widget build(BuildContext context) {
    final frac = (perHour / 6).clamp(0.0, 1.0).toDouble();
    const label = TextStyle(color: Colors.white70, fontSize: 11);
    return Column(
      children: [
        LayoutBuilder(
          builder: (context, c) {
            final w = c.maxWidth;
            return TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: frac),
              duration: const Duration(milliseconds: 900),
              curve: Curves.easeOutCubic,
              builder: (context, f, _) => SizedBox(
                height: 18,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      top: 5,
                      child: Container(
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xFFC62828),
                              Color(0xFFE0A100),
                              Color(0xFF1B8E5A),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: f * (w - 14),
                      top: 0,
                      child: Container(
                        width: 14,
                        height: 18,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: const [
                            BoxShadow(color: Colors.black38, blurRadius: 4),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 4),
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('\$0', style: label),
            Text('\$2/h', style: label),
            Text('\$4/h', style: label),
            Text('\$6+', style: label),
          ],
        ),
      ],
    );
  }
}

/// Mapa pequeño con el trazo de la ruta, origen, destino y casa.
class RouteMap extends StatelessWidget {
  final List<LatLng> route;
  final LatLng? start;
  final LatLng? end;
  final LatLng? home;
  final double height;

  const RouteMap({
    super.key,
    required this.route,
    this.start,
    this.end,
    this.home,
    this.height = 220,
  });

  @override
  Widget build(BuildContext context) {
    final pts = route.isNotEmpty
        ? route
        : <LatLng>[if (start != null) start!, if (end != null) end!];
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: SizedBox(
        height: height,
        child: FlutterMap(
          options: MapOptions(
            initialCenter: pts.isNotEmpty ? pts.first : const LatLng(13.6929, -89.2182),
            initialZoom: 12,
            initialCameraFit: pts.length >= 2
                ? CameraFit.bounds(
                    bounds: LatLngBounds.fromPoints(pts),
                    padding: const EdgeInsets.all(32),
                  )
                : null,
            interactionOptions: const InteractionOptions(
              flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
            ),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.rutaviva.rutaviva',
            ),
            if (route.isNotEmpty)
              PolylineLayer(
                polylines: [
                  Polyline(
                    points: route,
                    strokeWidth: 5,
                    color: const Color(0xFF1B8E5A),
                  ),
                ],
              ),
            MarkerLayer(
              markers: [
                if (start != null)
                  Marker(
                    point: start!,
                    width: 36,
                    height: 36,
                    child: const Icon(Icons.trip_origin, color: Colors.blue, size: 30),
                  ),
                if (end != null)
                  Marker(
                    point: end!,
                    width: 40,
                    height: 40,
                    child: const Icon(Icons.location_on, color: Colors.red, size: 38),
                  ),
                if (home != null)
                  Marker(
                    point: home!,
                    width: 36,
                    height: 36,
                    child: const Icon(Icons.home, color: Colors.orange, size: 30),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
