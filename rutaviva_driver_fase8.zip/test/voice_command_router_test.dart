import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/voice_command_router.dart';

void main() {
  group('VoiceCommandRouter: simulación sin micrófono', () {
    late VoiceCommandRouter router;
    late DateTime now;
    late VoiceOffer offer;

    setUp(() {
      router = VoiceCommandRouter(confirmationTimeout: const Duration(seconds: 30));
      now = DateTime(2026, 10, 31, 12, 0);
      offer = VoiceOffer(price: 8.50, km: 12, minutes: 28);
    });

    test('una oferta reconocida solo se lee y queda pendiente de confirmación', () {
      final reply = router.offerDetected(offer, now: now);

      expect(reply.intent, VoiceIntent.offerReadback);
      expect(reply.shouldCalculate, isFalse);
      expect(reply.speech, contains('8.50 dólares'));
      expect(reply.speech, contains('12.0 kilómetros'));
      expect(reply.speech, contains('28 minutos'));
      expect(router.hasPendingOffer, isTrue);
    });

    test('normaliza mayúsculas, acentos, signos y espacios', () {
      final reply = router.handle('  ¿CUÁNTO   LLEVO HOY?  ', now: now);

      expect(reply.intent, VoiceIntent.dailySummary);
      expect(reply.shouldCalculate, isFalse);
      expect(reply.shouldStopListening, isFalse);
    });

    test('consulta de resumen no calcula ni elimina oferta pendiente', () {
      router.offerDetected(offer, now: now);
      final reply = router.handle('resumen de hoy', now: now);

      expect(reply.intent, VoiceIntent.dailySummary);
      expect(reply.shouldCalculate, isFalse);
      expect(router.hasPendingOffer, isTrue);
    });

    test('calcular sin una oferta confirmable nunca ejecuta cálculo', () {
      final reply = router.handle('calcular', now: now);

      expect(reply.intent, VoiceIntent.unknown);
      expect(reply.shouldCalculate, isFalse);
      expect(reply.offer, isNull);
    });

    test('confirmación explícita devuelve una sola oferta para calcular', () {
      router.offerDetected(offer, now: now);
      final reply = router.handle('¡SÍ, CALCULAR!', now: now);

      expect(reply.intent, VoiceIntent.confirmCalculation);
      expect(reply.shouldCalculate, isTrue);
      expect(reply.offer, same(offer));
      expect(router.hasPendingOffer, isFalse);
    });

    test('una confirmación duplicada no produce un segundo cálculo', () {
      router.offerDetected(offer, now: now);
      final first = router.handle('confirmar', now: now);
      final second = router.handle('calcular', now: now);

      expect(first.shouldCalculate, isTrue);
      expect(second.shouldCalculate, isFalse);
      expect(second.offer, isNull);
    });

    test('cancelar borra la oferta pendiente y no calcula', () {
      router.offerDetected(offer, now: now);
      final reply = router.handle('cancelar', now: now);

      expect(reply.intent, VoiceIntent.cancel);
      expect(reply.shouldCalculate, isFalse);
      expect(router.hasPendingOffer, isFalse);
    });

    test('una respuesta afirmativa sin pendiente no calcula', () {
      final reply = router.handle('sí', now: now);

      expect(reply.shouldCalculate, isFalse);
      expect(reply.offer, isNull);
    });

    test('confirmación vencida se descarta en el límite de tiempo', () {
      router.offerDetected(offer, now: now);
      final reply = router.handle(
        'calcular',
        now: now.add(const Duration(seconds: 30)),
      );

      expect(reply.intent, VoiceIntent.cancel);
      expect(reply.shouldCalculate, isFalse);
      expect(router.hasPendingOffer, isFalse);
      expect(reply.speech, contains('venció'));
    });

    test('una nueva oferta no reemplaza silenciosamente otra pendiente', () {
      router.offerDetected(offer, now: now);
      final replacement = VoiceOffer(price: 14, km: 20, minutes: 40);
      final reply = router.offerDetected(replacement, now: now);
      final confirmed = router.handle('calcular', now: now);

      expect(reply.intent, VoiceIntent.unknown);
      expect(confirmed.offer, same(offer));
      expect(confirmed.shouldCalculate, isTrue);
    });

    test('repetir devuelve el último mensaje sin volver a calcular', () {
      final readback = router.offerDetected(offer, now: now);
      final repeat = router.handle('repite', now: now);

      expect(repeat.intent, VoiceIntent.repeat);
      expect(repeat.speech, readback.speech);
      expect(repeat.shouldCalculate, isFalse);
      expect(router.hasPendingOffer, isTrue);
    });

    test('detener voz limpia oferta y solicita detener reconocimiento', () {
      router.offerDetected(offer, now: now);
      final reply = router.handle('detener voz', now: now);

      expect(reply.intent, VoiceIntent.stopListening);
      expect(reply.shouldStopListening, isTrue);
      expect(reply.shouldCalculate, isFalse);
      expect(router.hasPendingOffer, isFalse);
    });

    test('texto no reconocido no invoca acciones ni acepta viajes', () {
      for (final phrase in ['acepta el viaje', 'abre inDrive', 'haz lo que quieras']) {
        final reply = router.handle(phrase, now: now);
        expect(reply.intent, VoiceIntent.unknown, reason: phrase);
        expect(reply.shouldCalculate, isFalse, reason: phrase);
        expect(reply.shouldStopListening, isFalse, reason: phrase);
      }
    });

    test('frase vacía devuelve una instrucción y no ejecuta acciones', () {
      final reply = router.handle('   ', now: now);

      expect(reply.intent, VoiceIntent.unknown);
      expect(reply.shouldCalculate, isFalse);
      expect(reply.speech, contains('No escuché'));
    });

    test('rechaza ofertas con precio, distancia o tiempo inválidos', () {
      expect(
        () => VoiceOffer(price: 0, km: 12, minutes: 28),
        throwsArgumentError,
      );
      expect(
        () => VoiceOffer(price: 8.5, km: double.nan, minutes: 28),
        throwsArgumentError,
      );
      expect(
        () => VoiceOffer(price: 8.5, km: 12, minutes: -1),
        throwsArgumentError,
      );
    });

    test('rechaza ventana de confirmación cero o negativa', () {
      expect(
        () => VoiceCommandRouter(confirmationTimeout: Duration.zero),
        throwsArgumentError,
      );
      expect(
        () => VoiceCommandRouter(
          confirmationTimeout: const Duration(seconds: -1),
        ),
        throwsArgumentError,
      );
    });
  });
}
