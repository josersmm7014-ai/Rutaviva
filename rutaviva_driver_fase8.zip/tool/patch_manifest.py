"""Prepara el proyecto Android generado:
- agrega permisos y servicios al AndroidManifest
- copia MainActivity.kt y CaptureService.kt (captura de pantalla)
"""
import os
import re
import shutil
import sys

path = sys.argv[1]
xml = open(path, encoding="utf-8").read()

# Nombre visible en el launcher y en los ajustes de Android.
def rename_application(match):
    attrs = match.group(1)
    if re.search(r'android:label="[^"]*"', attrs):
        attrs = re.sub(r'android:label="[^"]*"', 'android:label="RutaNeta"', attrs, count=1)
    else:
        attrs += ' android:label="RutaNeta"'
    return '<application' + attrs + '>'

xml = re.sub(r'<application([^>]*)>', rename_application, xml, count=1)

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
"""

overlay_service = """        <service
            android:name="flutter.overlay.window.flutter_overlay_window.OverlayService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Burbuja flotante con la ganancia del conductor"/>
        </service>
"""

capture_service = """        <service
            android:name="com.rutaviva.rutaviva.CaptureService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection"/>
"""

if "SYSTEM_ALERT_WINDOW" not in xml:
    xml = xml.replace("<application", perms + "    <application", 1)
if "OverlayService" not in xml:
    xml = xml.replace("</application>", overlay_service + "    </application>", 1)
if "CaptureService" not in xml:
    xml = xml.replace("</application>", capture_service + "    </application>", 1)

open(path, "w", encoding="utf-8").write(xml)
print("Manifest parchado")

# Copiar los archivos Kotlin junto al MainActivity generado
here = os.path.dirname(os.path.abspath(__file__))
main_dir = os.path.dirname(os.path.abspath(path))
dest = None
for d, _, files in os.walk(main_dir):
    if "MainActivity.kt" in files:
        dest = d
        break
if dest is None:
    raise SystemExit("No se encontro MainActivity.kt en el scaffold")
for name in ("MainActivity.kt", "CaptureService.kt"):
    shutil.copy(os.path.join(here, "android", name), os.path.join(dest, name))
print("Kotlin copiado a", dest)
