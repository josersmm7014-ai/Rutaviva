# Scripts de desarrollo: simulación del asistente de voz

## Estado y límites

Este conjunto prueba **la lógica de comandos**, no el reconocimiento real del micrófono. El asistente todavía no está conectado a Speech-to-Text, Text-to-Speech, OCR, resúmenes reales ni la interfaz de RutaNeta. El simulador usa transcripciones escritas, una oferta ficticia y un resumen ficticio; no llama a otras apps, no altera viajes y no consume cuota.

Archivos incluidos:

- `lib/voice_command_router.dart`: enrutador puro de transcripciones, oferta pendiente, timeout y salvaguardas.
- `test/voice_command_router_test.dart`: pruebas automatizadas con `flutter_test`.
- `tool/voice_simulator.dart`: simulador interactivo de terminal, sin plugins ni permisos.

## 1. Requisitos

Desde la raíz del proyecto se necesita Flutter/Dart compatible con `pubspec.yaml` (Dart 3.8 o posterior). El simulador no requiere permisos de Android, micrófono, Bluetooth, internet ni claves/API.

## 2. Ejecutar las pruebas automatizadas

```bash
flutter pub get
flutter test test/voice_command_router_test.dart
```

El archivo automatizado comprueba: lectura de oferta sin cálculo anticipado, normalización de español, resumen sin side effects, confirmación única, rechazo de confirmación sin oferta, cancelación, vencimiento a los 30 segundos, prevención de doble cálculo, rechazo de intenciones arbitrarias, repetición y detener voz. También prueba que valores inválidos y timeouts no positivos no sean admitidos.

Resultado esperado: todas las pruebas pasan. Si una falla, guardar la salida del test como incidencia y no conectar todavía el enrutador al micrófono ni a un cálculo real.

## 3. Ejecutar el simulador interactivo

```bash
dart run tool/voice_simulator.dart
```

El teclado representa una transcripción que hipotéticamente habría devuelto un motor STT; la salida de terminal representa lo que la app anunciaría. Comandos especiales del simulador:

- `:ayuda`: muestra la lista de comandos.
- `:oferta`: carga datos sintéticos: $8.50, 12 km y 28 minutos.
- `:ocr-incompleto`: simula OCR incompleto; no crea una oferta nueva.
- `:avanzar-tiempo 31`: adelanta 31 segundos para probar vencimiento.
- `:reiniciar`: limpia el estado de prueba.
- `:salir`: cierra el programa.

## 4. Guiones manuales

### Guion A — recorrido esperado

Entrada:

```text
:oferta
calcular
```

Esperado: primero anuncia los tres valores y pide «calcular» o «cancelar»; solo después de la transcripción `calcular` aparece `ACCIÓN SIMULADA`. El script debe indicar que no invoca el motor real ni cambia el contador.

### Guion B — no confirmar

Entrada:

```text
:oferta
repetir
cancelar
calcular
```

Esperado: `repetir` vuelve a decir la lectura; `cancelar` descarta la oferta; el último `calcular` informa que no existe oferta pendiente y no debe emitir `ACCIÓN SIMULADA`.

### Guion C — caducidad

Entrada:

```text
:oferta
:avanzar-tiempo 31
calcular
```

Esperado: la confirmación caducó, solicita volver a leer la oferta y no calcula.

### Guion D — comandos no permitidos

Entrada:

```text
acepta el viaje
abre inDrive
haz lo que quieras
```

Esperado: las tres frases se marcan `unknown`; ninguna abre apps, acepta viajes ni produce `ACCIÓN SIMULADA`.

### Guion E — resumen y detener

Entrada:

```text
resumen de hoy
detener voz
```

Esperado: se reconoce la intención de resumen y se imprimen los datos **ficticios** de prueba; `detener voz` emite `shouldStopListening=true`. El simulador continúa activo para que se puedan probar más casos, pero el estado indica que la escucha hipotética debería parar.

### Guion F — oferta incompleta

Entrada:

```text
:ocr-incompleto
calcular
```

Esperado: el OCR simulado explica que faltan minutos y `calcular` no produce acción porque no hay oferta pendiente.

## 5. Revisión de regresión antes de integrar STT/TTS

Cuando se integre Speech-to-Text, debe ser la capa de audio la que pase una transcripción final a `VoiceCommandRouter.handle`. No llamar a `handle` con fragmentos parciales para confirmar una acción. La app debe pedir confirmación hablada y visible, iniciar un timeout de 30 segundos y ejecutar el cálculo únicamente cuando `VoiceReply.shouldCalculate` sea `true` y venga adjunta la oferta pendiente. Consumir una oferta solo una vez.

Antes de conectar la salida TTS, confirmar que:

1. La frase desconocida nunca se mapea a `confirmCalculation`.
2. Cancelar, detener, caducar o revocar micrófono limpian la operación pendiente.
3. La confirmación duplicada no genera segundo cálculo ni segundo descuento.
4. Los resúmenes usan datos locales actuales, no los valores ficticios del CLI.
5. Ningún audio, transcripción completa, nombre de pasajero o dirección queda en logs o almacenamiento.

La validación del micrófono y Bluetooth debe realizarse después, en teléfonos de prueba y **con el vehículo detenido y asegurado**. Este conjunto no autoriza ni requiere probar el sistema mientras se conduce.
