import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrResult {
  final double? price;
  final double? km;
  final double? minutes;
  final String text;
  const OcrResult({this.price, this.km, this.minutes, required this.text});
}

double? _num(String s) => double.tryParse(s.replaceAll(',', '.'));

/// Lee una captura y trata de encontrar precio, km y minutos.
/// Si hay varios km o minutos (recogida y viaje), toma el mayor, que
/// normalmente es el del viaje. Siempre hay que revisar los valores.
Future<OcrResult> readScreenshot(String path) async {
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  try {
    final input = InputImage.fromFilePath(path);
    final result = await recognizer.recognizeText(input);
    final text = result.text;

    double? price;
    final priceMatch = RegExp(r'\$\s*(\d+(?:[.,]\d{1,2})?)').firstMatch(text);
    if (priceMatch != null) price = _num(priceMatch.group(1)!);

    double? km;
    for (final m in RegExp(r'(\d+(?:[.,]\d+)?)\s*km', caseSensitive: false)
        .allMatches(text)) {
      final v = _num(m.group(1)!);
      if (v != null && (km == null || v > km)) km = v;
    }

    double? minutes;
    for (final m
        in RegExp(r'(\d+)\s*min', caseSensitive: false).allMatches(text)) {
      final v = _num(m.group(1)!);
      if (v != null && (minutes == null || v > minutes)) minutes = v;
    }

    return OcrResult(price: price, km: km, minutes: minutes, text: text);
  } finally {
    await recognizer.close();
  }
}
