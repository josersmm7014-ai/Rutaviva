import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'geo.dart';
import 'models.dart';
import 'ocr.dart';
import 'overlay.dart';
import 'store.dart';

// ---------------------------------------------------------------- helpers

String money(double v) => '\$${v.toStringAsFixed(2)}';

double? parseNum(String s) => double.tryParse(s.trim().replaceAll(',', '.'));

Color verdictColor(String v) {
  if (v == 'CONVIENE') return const Color(0xFF1B8E5A);
  if (v == 'DUDOSO') return const Color(0xFFE0A100);
  return const Color(0xFFC62828);
}

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

// ---------------------------------------------------------------- vehículo

class VehicleFields extends StatefulWidget {
  final Vehicle? initial;
  final bool withGoal;
  final String buttonLabel;
  final void Function(Vehicle) onSave;

  const VehicleFields({
    super.key,
    this.initial,
    this.withGoal = false,
    required this.buttonLabel,
    required this.onSave,
  });

  @override
  State<VehicleFields> createState() => _VehicleFieldsState();
}

class _VehicleFieldsState extends State<VehicleFields> {
  String engine = '1.6';
  String fuel = 'Regular';
  final kmCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  final goalCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final v = widget.initial;
    if (v != null) {
      engine = v.engine;
      fuel = v.fuel;
      kmCtrl.text = v.kmPerGal.toString();
      priceCtrl.text = v.fuelPrice.toString();
      goalCtrl.text = v.dailyGoal.toString();
    } else {
      goalCtrl.text = '25';
    }
  }

  @override
  void dispose() {
    kmCtrl.dispose();
    priceCtrl.dispose();
    goalCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final km = parseNum(kmCtrl.text);
    final price = parseNum(priceCtrl.text);
    final goal = parseNum(goalCtrl.text) ?? 25;
    if (km == null || km <= 0 || price == null || price <= 0) {
      snack(context, 'Revisa el consumo y el precio del combustible');
      return;
    }
    widget.onSave(Vehicle(
      engine: engine,
      fuel: fuel,
      kmPerGal: km,
      fuelPrice: price,
      dailyGoal: goal,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<String>(
          value: engine,
          decoration: const InputDecoration(labelText: 'Tipo de motor'),
          items: const ['1.2', '1.6', '2.0']
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: (v) => setState(() => engine = v ?? engine),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: fuel,
          decoration: const InputDecoration(labelText: 'Combustible'),
          items: const ['Especial', 'Regular', 'Diesel']
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: (v) => setState(() => fuel = v ?? fuel),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: kmCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Consumo promedio (km por galón)',
            hintText: 'Ej: 35',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: priceCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Precio actual del galón (\$)',
            helperText: 'Puedes editarlo cuando cambie',
          ),
        ),
        if (widget.withGoal) ...[
          const SizedBox(height: 12),
          TextField(
            controller: goalCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Meta diaria (\$)'),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(onPressed: _save, child: Text(widget.buttonLabel)),
      ],
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int step = 0;
  Vehicle? draft;
  final goalCtrl = TextEditingController(text: '25');

  @override
  void dispose() {
    goalCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    String title;
    if (step == 0) {
      title = '1. Configura tu carro';
      body = VehicleFields(
        buttonLabel: 'Siguiente',
        onSave: (v) => setState(() {
          draft = v;
          step = 1;
        }),
      );
    } else if (step == 1) {
      title = '2. Pon tu meta diaria';
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('¿Cuánto quieres ganar neto por día?'),
          const SizedBox(height: 12),
          TextField(
            controller: goalCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Meta diaria (\$)'),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () {
              final g = parseNum(goalCtrl.text);
              if (g == null || g <= 0) {
                snack(context, 'Escribe una meta válida');
                return;
              }
              draft!.dailyGoal = g;
              setState(() => step = 2);
            },
            child: const Text('Siguiente'),
          ),
        ],
      );
    } else {
      title = '3. Todo listo';
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Ya puedes calcular si un viaje conviene. Escribe origen, destino, '
            'precio, distancia y tiempo estimado del pedido de inDrive.',
          ),
          const SizedBox(height: 12),
          const Text(
            'El modo flotante, la lectura automática de capturas y el mapa de '
            'calor en vivo llegarán en las próximas actualizaciones.',
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () => store.setVehicle(draft!),
            child: const Text('Empezar'),
          ),
        ],
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('RutaViva')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('No trabajes más, trabaja rentable.',
              style: TextStyle(fontStyle: FontStyle.italic)),
          const SizedBox(height: 16),
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          body,
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- shell

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final pages = <Widget>[
          const HomeScreen(),
          const HistoryScreen(),
          const AlertsScreen(),
          const PassengersScreen(),
          const SettingsScreen(),
        ];
        return Scaffold(
          body: pages[index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (i) => setState(() => index = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home), label: 'Inicio'),
              NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Historial'),
              NavigationDestination(icon: Icon(Icons.warning_amber), label: 'Alertas'),
              NavigationDestination(icon: Icon(Icons.people), label: 'Pasajeros'),
              NavigationDestination(icon: Icon(Icons.settings), label: 'Ajustes'),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------- inicio

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final trips = store.todayTrips;
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final perHour = hours > 0 ? net / hours : 0.0;
    final goal = store.vehicle!.dailyGoal;
    final double progress = goal > 0 ? (net / goal).clamp(0.0, 1.0).toDouble() : 0.0;

    return Scaffold(
      appBar: AppBar(title: const Text('RutaViva')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ganancia neta hoy'),
                  Text(
                    money(net),
                    style: Theme.of(context)
                        .textTheme
                        .displaySmall
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('${money(perHour)} por hora  ·  ${trips.length} viajes'),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(value: progress, minHeight: 8),
                  const SizedBox(height: 6),
                  Text('Meta diaria: ${money(goal)}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 90,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CalcScreen()),
              ),
              icon: const Icon(Icons.calculate, size: 32),
              label: const Text('Calcular viaje'),
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              store.premium
                  ? 'Premium: cálculos ilimitados'
                  : 'Te quedan ${store.calcsLeft} cálculos hoy',
            ),
          ),
          const SizedBox(height: 16),
          const _FloatingCard(),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- calculadora

class CalcScreen extends StatefulWidget {
  const CalcScreen({super.key});

  @override
  State<CalcScreen> createState() => _CalcScreenState();
}

class _CalcScreenState extends State<CalcScreen> {
  final origin = TextEditingController();
  final dest = TextEditingController();
  final price = TextEditingController();
  final km = TextEditingController();
  final mins = TextEditingController();
  bool returnEmpty = true;
  bool busy = false;
  GeoPoint? destPoint;

  Future<void> _readCapture() async {
    final file = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (file == null) return;
    setState(() => busy = true);
    try {
      final r = await readScreenshot(file.path);
      if (!mounted) return;
      setState(() {
        if (r.price != null) price.text = r.price!.toString();
        if (r.km != null) km.text = r.km!.toString();
        if (r.minutes != null) mins.text = r.minutes!.toStringAsFixed(0);
      });
      final found = <String>[
        if (r.price != null) 'precio',
        if (r.km != null) 'km',
        if (r.minutes != null) 'minutos',
      ];
      snack(
        context,
        found.isEmpty
            ? 'No pude leer datos de la captura. Escríbelos a mano'
            : 'Leí: ${found.join(', ')}. Revisa que estén bien',
      );
    } catch (_) {
      if (mounted) snack(context, 'No se pudo leer la captura');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _autoRoute() async {
    if (origin.text.trim().isEmpty || dest.text.trim().isEmpty) {
      snack(context, 'Escribe origen y destino');
      return;
    }
    setState(() => busy = true);
    try {
      final a = await geocode(origin.text);
      final b = await geocode(dest.text);
      if (!mounted) return;
      if (a == null || b == null) {
        snack(context, 'No encontré una de las direcciones. Prueba con colonia y municipio');
        return;
      }
      final r = await drivingRoute(a, b);
      if (!mounted) return;
      if (r == null) {
        snack(context, 'No pude calcular la ruta');
        return;
      }
      setState(() {
        destPoint = b;
        km.text = r.km.toStringAsFixed(1);
        mins.text = (r.minutes * store.trafficFactor).toStringAsFixed(0);
      });
      snack(context, 'Distancia y tiempo calculados (tráfico ×${store.trafficFactor})');
    } catch (_) {
      if (mounted) snack(context, 'Sin conexión o el servicio de mapas no responde');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    origin.dispose();
    dest.dispose();
    price.dispose();
    km.dispose();
    mins.dispose();
    super.dispose();
  }

  void _calculate() {
    final p = parseNum(price.text);
    final k = parseNum(km.text);
    final m = parseNum(mins.text);
    if (p == null || p <= 0 || k == null || k <= 0 || m == null || m <= 0) {
      snack(context, 'Escribe precio, distancia y tiempo');
      return;
    }
    if (!store.canCalc) {
      snack(context, 'Llegaste al límite de $freeCalcsPerDay cálculos de hoy');
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const PremiumScreen()),
      );
      return;
    }
    store.useCalc();
    final v = store.vehicle!;
    final travel = returnEmpty ? k * 2 : k;
    final trip = Trip(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      date: DateTime.now(),
      origin: origin.text.trim(),
      destination: dest.text.trim(),
      price: p,
      km: k,
      minutes: m,
      returnEmpty: returnEmpty,
      fuelCost: v.fuelCostFor(travel),
    );
    final warnings = store.warningsFor('${origin.text} ${dest.text}');
    String? homeNote;
    if (store.homeMode) {
      if (!store.hasHome) {
        homeNote = 'Hacia casa está activo, pero no has guardado tu casa en Ajustes.';
      } else if (destPoint == null) {
        homeNote = 'Hacia casa activo: usa "Distancia automática" para verificar el destino.';
      } else {
        final d = haversineKm(GeoPoint(store.homeLat!, store.homeLon!), destPoint!);
        homeNote = d <= 5
            ? 'Hacia casa: el destino queda a ${d.toStringAsFixed(1)} km de tu casa (en línea recta). Dentro de tu zona.'
            : 'Fuera de Hacia casa: el destino queda a ${d.toStringAsFixed(1)} km de tu casa (máximo 5 km, en línea recta).';
      }
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ResultScreen(trip: trip, warnings: warnings, homeNote: homeNote),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calcular viaje')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (busy) const LinearProgressIndicator(),
          OutlinedButton.icon(
            onPressed: busy ? null : _readCapture,
            icon: const Icon(Icons.image_search),
            label: const Text('Leer captura de inDrive'),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: origin,
            decoration: const InputDecoration(labelText: 'Origen'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: dest,
            onChanged: (_) => destPoint = null,
            decoration: const InputDecoration(labelText: 'Destino'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: busy ? null : _autoRoute,
            icon: const Icon(Icons.route),
            label: const Text('Distancia automática'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: price,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Precio ofertado (\$)'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: km,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Distancia del viaje (km)',
              helperText: 'Automática, de la captura o la que te muestra inDrive',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: mins,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Tiempo estimado con tráfico (min)',
            ),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Posible regreso vacío'),
            subtitle: const Text('Cuenta el trayecto de vuelta (distancia y tiempo ×2)'),
            value: returnEmpty,
            onChanged: (v) => setState(() => returnEmpty = v),
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _calculate, child: const Text('Calcular')),
        ],
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final Trip trip;
  final List<String> warnings;
  final String? homeNote;

  const ResultScreen({
    super.key,
    required this.trip,
    required this.warnings,
    this.homeNote,
  });

  Widget _row(String a, String b, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(a, style: style), Text(b, style: style)],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final color = verdictColor(trip.verdict);
    return Scaffold(
      appBar: AppBar(title: const Text('Resultado')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 32),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Text(
                  trip.verdict,
                  style: const TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${money(trip.perHour)} por hora',
                  style: const TextStyle(fontSize: 22, color: Colors.white),
                ),
                Text(
                  'Ganancia neta ${money(trip.net)}',
                  style: const TextStyle(fontSize: 16, color: Colors.white),
                ),
              ],
            ),
          ),
          if (warnings.isNotEmpty) ...[
            const SizedBox(height: 16),
            for (final w in warnings)
              Card(
                color: const Color(0xFF5D4037),
                child: ListTile(
                  leading: const Icon(Icons.warning_amber),
                  title: Text(w),
                ),
              ),
          ],
          if (homeNote != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.home),
                title: Text(homeNote!),
              ),
            ),
          const SizedBox(height: 16),
          _row('Precio ofertado', money(trip.price)),
          _row('Combustible', '- ${money(trip.fuelCost)}'),
          _row('Comisión inDrive (15%)', '- ${money(trip.commission)}'),
          _row('Desgaste (\$0.03/km)', '- ${money(trip.wear)}'),
          const Divider(),
          _row('Ganancia neta', money(trip.net), bold: true),
          _row('Km recorridos', '${trip.travelKm.toStringAsFixed(1)} km'),
          _row('Tiempo', '${(trip.hours * 60).toStringAsFixed(0)} min'),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () {
              final messenger = ScaffoldMessenger.of(context);
              store.addTrip(trip);
              Navigator.of(context).popUntil((r) => r.isFirst);
              messenger.showSnackBar(
                const SnackBar(content: Text('Viaje guardado. Ciérralo desde Historial')),
              );
            },
            child: const Text('Acepté este viaje'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Volver'),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- historial

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  int period = 0; // 0 hoy, 1 semana

  Future<void> _finish(Trip t) async {
    final fuelCtrl = TextEditingController(text: t.fuelCost.toStringAsFixed(2));
    bool empty = t.returnEmpty;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Finalizar viaje'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: fuelCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: '¿Cuánto gastaste real? (\$)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('¿Regresaste vacío?'),
                value: empty,
                onChanged: (v) => setD(() => empty = v),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () {
                final f = parseNum(fuelCtrl.text);
                if (f == null || f < 0) return;
                store.finishTrip(t, f, empty);
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
    fuelCtrl.dispose();
  }

  Future<void> _confirmDelete(Trip t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Borrar este viaje?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Borrar')),
        ],
      ),
    );
    if (ok == true) store.deleteTrip(t);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startToday = DateTime(now.year, now.month, now.day);
    final from = period == 0 ? startToday : startToday.subtract(const Duration(days: 6));
    final trips = store.tripsSince(from);

    final gross = trips.fold<double>(0, (s, t) => s + t.price);
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final km = trips.fold<double>(0, (s, t) => s + t.travelKm);
    final emptyKm = trips.fold<double>(0, (s, t) => s + (t.returnEmpty ? t.km : 0));
    final perHour = hours > 0 ? net / hours : 0.0;
    final emptyPct = km > 0 ? emptyKm / km * 100 : 0.0;
    final lost = trips.fold<double>(0, (s, t) => s + (t.net < 0 ? -t.net : 0));

    // Zona y hora más rentables
    final byZone = <String, List<double>>{};
    final byHour = <int, List<double>>{};
    for (final t in trips) {
      if (t.origin.isNotEmpty) byZone.putIfAbsent(t.origin, () => []).add(t.perHour);
      byHour.putIfAbsent(t.date.hour, () => []).add(t.perHour);
    }
    double avg(List<double> l) => l.fold<double>(0, (a, b) => a + b) / l.length;
    String? bestZone;
    double bestZoneVal = -1e9;
    byZone.forEach((k, v) {
      if (avg(v) > bestZoneVal) {
        bestZoneVal = avg(v);
        bestZone = k;
      }
    });
    int? bestHour;
    double bestHourVal = -1e9;
    byHour.forEach((k, v) {
      if (avg(v) > bestHourVal) {
        bestHourVal = avg(v);
        bestHour = k;
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Historial')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Hoy')),
              ButtonSegment(value: 1, label: Text('7 días')),
            ],
            selected: {period},
            onSelectionChanged: (s) => setState(() => period = s.first),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _stat('Total bruto', money(gross)),
                  _stat('Total neto', money(net)),
                  _stat('Horas trabajadas', hours.toStringAsFixed(1)),
                  _stat('\$ por hora', money(perHour)),
                  _stat('Km totales', km.toStringAsFixed(1)),
                  _stat('Km vacíos', '${emptyPct.toStringAsFixed(0)}%'),
                  _stat('Perdido en viajes malos', money(lost)),
                  if (bestZone != null) _stat('Zona más rentable', bestZone!),
                  if (bestHour != null) _stat('Hora más rentable', '$bestHour:00'),
                ],
              ),
            ),
          ),
          if (emptyPct >= 40)
            const Card(
              child: ListTile(
                leading: Icon(Icons.lightbulb_outline),
                title: Text(
                  'Más del 40% de tus km van vacíos. Prefiere viajes que te dejen '
                  'cerca de zonas con demanda.',
                ),
              ),
            ),
          const SizedBox(height: 8),
          if (trips.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('Todavía no hay viajes en este periodo')),
            ),
          for (final t in trips)
            Card(
              child: ListTile(
                onTap: t.finished ? null : () => _finish(t),
                onLongPress: () => _confirmDelete(t),
                leading: CircleAvatar(
                  backgroundColor: verdictColor(t.verdict),
                  child: Icon(t.finished ? Icons.check : Icons.hourglass_bottom,
                      color: Colors.white),
                ),
                title: Text(
                  t.origin.isEmpty && t.destination.isEmpty
                      ? 'Viaje ${money(t.price)}'
                      : '${t.origin.isEmpty ? '?' : t.origin} → ${t.destination.isEmpty ? '?' : t.destination}',
                ),
                subtitle: Text(
                  'Neto ${money(t.net)} · ${money(t.perHour)}/h · ${t.km.toStringAsFixed(1)} km'
                  '${t.finished ? '' : '\nToca para finalizar'}',
                ),
                isThreeLine: !t.finished,
              ),
            ),
          const SizedBox(height: 8),
          const Text(
            'Mantén presionado un viaje para borrarlo.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _stat(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.bold))],
        ),
      );
}

// ---------------------------------------------------------------- alertas

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  Future<void> _add(BuildContext context) async {
    String type = alertTypes.first;
    final zoneCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Nueva alerta'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: type,
                items: alertTypes
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (v) => setD(() => type = v ?? type),
              ),
              TextField(
                controller: zoneCtrl,
                decoration: const InputDecoration(labelText: 'Zona o lugar'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () {
                if (zoneCtrl.text.trim().isEmpty) return;
                store.addAlert(AlertItem(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  type: type,
                  zone: zoneCtrl.text.trim(),
                  created: DateTime.now(),
                ));
                Navigator.pop(ctx);
              },
              child: const Text('Publicar'),
            ),
          ],
        ),
      ),
    );
    zoneCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = store.activeAlerts;
    return Scaffold(
      appBar: AppBar(title: const Text('Alertas')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _add(context),
        icon: const Icon(Icons.add_alert),
        label: const Text('Nueva'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Cada alerta dura 2 horas. En esta versión las alertas se guardan solo '
            'en tu teléfono; compartirlas entre conductores llegará con el servidor.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (list.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('No hay alertas activas')),
            ),
          for (final a in list)
            Card(
              child: ListTile(
                title: Text(a.type),
                subtitle: Text(
                  '${a.zone} · hace ${DateTime.now().difference(a.created).inMinutes} min\n'
                  '${a.yes} siguen vigente · ${a.no} ya no',
                ),
                isThreeLine: true,
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.thumb_up_alt_outlined),
                      onPressed: () => store.voteAlert(a, true),
                    ),
                    IconButton(
                      icon: const Icon(Icons.thumb_down_alt_outlined),
                      onPressed: () => store.voteAlert(a, false),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- pasajeros y zonas

class PassengersScreen extends StatelessWidget {
  const PassengersScreen({super.key});

  Future<void> _add(BuildContext context) async {
    final nameCtrl = TextEditingController();
    String kind = 'zona';
    final tags = <String>{};
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Marcar pasajero o zona'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'zona', label: Text('Zona')),
                    ButtonSegment(value: 'persona', label: Text('Pasajero')),
                  ],
                  selected: {kind},
                  onSelectionChanged: (s) => setD(() => kind = s.first),
                ),
                TextField(
                  controller: nameCtrl,
                  decoration: InputDecoration(
                    labelText: kind == 'zona' ? 'Nombre de la colonia' : 'Nombre o teléfono',
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final t in passengerTags)
                      FilterChip(
                        label: Text(t),
                        selected: tags.contains(t),
                        onSelected: (v) => setD(() {
                          if (v) {
                            tags.add(t);
                          } else {
                            tags.remove(t);
                          }
                        }),
                      ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            FilledButton(
              onPressed: () {
                if (nameCtrl.text.trim().isEmpty || tags.isEmpty) return;
                store.addPassenger(Passenger(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  name: nameCtrl.text.trim(),
                  kind: kind,
                  tags: tags.toList(),
                ));
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
    nameCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = store.passengers;
    return Scaffold(
      appBar: AppBar(title: const Text('Pasajeros y zonas')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _add(context),
        icon: const Icon(Icons.add),
        label: const Text('Marcar'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Privado: esta lista vive solo en tu teléfono, no se sube a ningún servidor. '
            'Si el origen o destino de un cálculo coincide con un nombre de aquí, te avisamos.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (list.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('Aún no has marcado a nadie')),
            ),
          for (final p in list)
            Card(
              child: ListTile(
                leading: Icon(p.kind == 'zona' ? Icons.place : Icons.person),
                title: Text(p.name),
                subtitle: Text(p.tags.join(' · ')),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => store.deletePassenger(p),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- ajustes

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _editTraffic(BuildContext context) async {
    final ctrl = TextEditingController(text: store.trafficFactor.toString());
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Factor de tráfico'),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            helperText: 'Entre 1.0 y 3.0. Ej: 1.3 suma 30% al tiempo',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          FilledButton(
            onPressed: () {
              final v = parseNum(ctrl.text);
              if (v == null || v < 1 || v > 3) return;
              store.setTrafficFactor(v);
              Navigator.pop(ctx);
            },
            child: const Text('Guardar'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = store.vehicle!;
    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.directions_car),
            title: const Text('Mi vehículo'),
            subtitle: Text(
              'Motor ${v.engine} · ${v.fuel} · ${v.kmPerGal} km/gal · ${money(v.fuelPrice)}/gal',
            ),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const VehicleScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.traffic),
            title: const Text('Factor de tráfico'),
            subtitle: Text(
              '×${store.trafficFactor} sobre el tiempo de ruta (1.0 = sin tráfico)',
            ),
            onTap: () => _editTraffic(context),
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Mi casa (para Hacia casa)'),
            subtitle: Text(store.hasHome ? store.homeAddress : 'Sin guardar'),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const HomeSetupScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.map),
            title: const Text('Mapa de calor'),
            subtitle: const Text('Vista de ejemplo'),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const HeatMapScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.workspace_premium),
            title: const Text('Premium'),
            subtitle: Text(store.premium ? 'Activo (modo prueba)' : 'Plan gratis'),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const PremiumScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever),
            title: const Text('Borrar todos mis datos'),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('¿Borrar todo?'),
                  content: const Text('Se borrarán vehículo, viajes, alertas y marcas.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Cancelar')),
                    FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Borrar')),
                  ],
                ),
              );
              if (ok == true) await store.resetAll();
            },
          ),
        ],
      ),
    );
  }
}

class VehicleScreen extends StatelessWidget {
  const VehicleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi vehículo')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          VehicleFields(
            initial: store.vehicle,
            withGoal: true,
            buttonLabel: 'Guardar',
            onSave: (v) {
              store.setVehicle(v);
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- mapa de calor (ejemplo)

class HeatMapScreen extends StatelessWidget {
  const HeatMapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Datos simulados de ejemplo (\$ por km).
    const zones = <String, double>{
      'San Salvador': 0.45,
      'Santa Tecla': 0.62,
      'Soyapango': 0.30,
      'Apopa': 0.22,
    };
    Color c(double v) {
      if (v >= 0.60) return const Color(0xFF0B5D36);
      if (v >= 0.40) return const Color(0xFF6BBF59);
      if (v >= 0.25) return const Color(0xFFE0A100);
      return const Color(0xFFC62828);
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Mapa de calor')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text(
                'Datos simulados de ejemplo. El mapa real con precios por km y '
                'pedidos en vivo llegará en la siguiente fase.',
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final e in zones.entries)
            Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: c(e.value)),
                title: Text(e.key),
                trailing: Text('${money(e.value)}/km'),
              ),
            ),
          const SizedBox(height: 12),
          const Text('Verde oscuro: \$0.60+/km · Verde claro: \$0.40 · '
              'Amarillo: \$0.25 · Rojo: menos de \$0.25 o mucho tráfico'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- premium

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  Widget _item(String t, {bool ok = true}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Icon(ok ? Icons.check_circle : Icons.circle_outlined, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(t)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Premium')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Gratis', style: Theme.of(context).textTheme.titleLarge),
            _item('$freeCalcsPerDay cálculos por día'),
            _item('Historial, pasajeros y alertas locales'),
            const SizedBox(height: 20),
            Text('Premium  ·  \$2.99/mes o \$19.99/año',
                style: Theme.of(context).textTheme.titleLarge),
            _item('Cálculos ilimitados'),
            _item('Mapa en tiempo real (próximamente)'),
            _item('Predicción de demanda (próximamente)'),
            _item('Exportar reporte a Excel (próximamente)'),
            _item('Sin anuncios'),
            const SizedBox(height: 20),
            const Text(
              'Los pagos todavía no están conectados. Mientras tanto puedes probar '
              'Premium con este interruptor.',
              style: TextStyle(fontSize: 12),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Activar Premium (modo prueba)'),
              value: store.premium,
              onChanged: store.setPremium,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- modo flotante

class _FloatingCard extends StatefulWidget {
  const _FloatingCard();

  @override
  State<_FloatingCard> createState() => _FloatingCardState();
}

class _FloatingCardState extends State<_FloatingCard> {
  bool active = false;

  @override
  void initState() {
    super.initState();
    OverlayCtrl.isActive().then((v) {
      if (mounted) setState(() => active = v);
    });
  }

  Future<void> _toggle(bool on) async {
    if (on) {
      final ok = await OverlayCtrl.start();
      if (!mounted) return;
      if (!ok) {
        snack(context, 'Necesito el permiso "Mostrar sobre otras apps"');
      }
      setState(() => active = ok);
    } else {
      await OverlayCtrl.stop();
      if (mounted) setState(() => active = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SwitchListTile(
        secondary: const Icon(Icons.bubble_chart),
        title: const Text('Modo flotante'),
        subtitle: const Text(
          'Burbuja sobre inDrive con tu ganancia de hoy y el botón Hacia casa',
        ),
        value: active,
        onChanged: _toggle,
      ),
    );
  }
}

// ---------------------------------------------------------------- mi casa

class HomeSetupScreen extends StatefulWidget {
  const HomeSetupScreen({super.key});

  @override
  State<HomeSetupScreen> createState() => _HomeSetupScreenState();
}

class _HomeSetupScreenState extends State<HomeSetupScreen> {
  final ctrl = TextEditingController(text: store.homeAddress);
  bool busy = false;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (ctrl.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      final p = await geocode(ctrl.text);
      if (!mounted) return;
      if (p == null) {
        snack(context, 'No encontré esa dirección. Prueba con colonia y municipio');
        return;
      }
      store.setHome(ctrl.text.trim(), p.lat, p.lon);
      Navigator.of(context).pop();
    } catch (_) {
      if (mounted) snack(context, 'Sin conexión o el servicio de mapas no responde');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi casa')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Con "Hacia casa" activo te aviso si el destino de un viaje queda a más de 5 km de tu casa. '
            'La dirección se guarda solo en tu teléfono.',
          ),
          const SizedBox(height: 16),
          TextField(
            controller: ctrl,
            decoration: const InputDecoration(
              labelText: 'Colonia y municipio',
              hintText: 'Ej: Colonia Escalón, San Salvador',
            ),
          ),
          const SizedBox(height: 16),
          if (busy) const LinearProgressIndicator(),
          FilledButton(
            onPressed: busy ? null : _save,
            child: const Text('Guardar'),
          ),
        ],
      ),
    );
  }
}
