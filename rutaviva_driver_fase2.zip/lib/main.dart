import 'package:flutter/material.dart';
import 'overlay.dart';
import 'screens.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  OverlayCtrl.init();
  runApp(const RutaVivaApp());
}

/// Punto de entrada de la burbuja flotante (lo llama el plugin de overlay).
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: OverlayBubble(),
  ));
}

class RutaVivaApp extends StatelessWidget {
  const RutaVivaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RutaViva',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B8E5A),
          brightness: Brightness.dark,
        ),
      ),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) =>
            store.vehicle == null ? const OnboardingScreen() : const MainShell(),
      ),
    );
  }
}
