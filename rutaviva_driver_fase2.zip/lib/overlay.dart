import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'store.dart';

/// Lado de la app principal: abre/cierra la burbuja y le envía los datos.
class OverlayCtrl {
  static bool _listening = false;

  /// Llamar una vez al iniciar la app.
  static void init() {
    if (_listening) return;
    _listening = true;
    store.addListener(push);
    FlutterOverlayWindow.overlayListener.listen((event) {
      if (event == 'toggleHome') {
        store.toggleHomeMode();
      } else if (event == 'ready') {
        push();
      }
    });
  }

  static Future<bool> isActive() => FlutterOverlayWindow.isActive();

  /// Pide el permiso de dibujar sobre otras apps y abre la burbuja.
  static Future<bool> start() async {
    var ok = await FlutterOverlayWindow.isPermissionGranted();
    if (!ok) {
      ok = (await FlutterOverlayWindow.requestPermission()) ?? false;
    }
    if (!ok) return false;
    if (!await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'RutaViva',
        overlayContent: 'Burbuja activa',
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        height: 420,
        width: 620,
      );
    }
    Future.delayed(const Duration(milliseconds: 800), push);
    return true;
  }

  static Future<void> stop() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
    }
  }

  static Future<void> push() async {
    try {
      if (!await FlutterOverlayWindow.isActive()) return;
      final trips = store.todayTrips;
      final net = trips.fold<double>(0, (s, t) => s + t.net);
      final hours = trips.fold<double>(0, (s, t) => s + t.hours);
      final kmPass = trips.fold<double>(0, (s, t) => s + t.km);
      final kmEmpty =
          trips.fold<double>(0, (s, t) => s + (t.returnEmpty ? t.km : 0));
      await FlutterOverlayWindow.shareData(jsonEncode({
        'net': net,
        'perHour': hours > 0 ? net / hours : 0.0,
        'kmPass': kmPass,
        'kmEmpty': kmEmpty,
        'homeMode': store.homeMode,
      }));
    } catch (_) {
      // Si la burbuja no está lista, se reintenta en el próximo cambio.
    }
  }
}

/// Lado de la burbuja (corre en su propio proceso de Flutter).
class OverlayBubble extends StatefulWidget {
  const OverlayBubble({super.key});

  @override
  State<OverlayBubble> createState() => _OverlayBubbleState();
}

class _OverlayBubbleState extends State<OverlayBubble> {
  double net = 0;
  double perHour = 0;
  double kmPass = 0;
  double kmEmpty = 0;
  bool homeMode = false;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FlutterOverlayWindow.overlayListener.listen((event) {
      try {
        final m = jsonDecode('$event') as Map<String, dynamic>;
        setState(() {
          net = (m['net'] as num).toDouble();
          perHour = (m['perHour'] as num).toDouble();
          kmPass = (m['kmPass'] as num).toDouble();
          kmEmpty = (m['kmEmpty'] as num).toDouble();
          homeMode = m['homeMode'] as bool;
        });
      } catch (_) {}
    });
    FlutterOverlayWindow.shareData('ready');
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  String _m(double v) => '\$${v.toStringAsFixed(2)}';

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF1B8E5A);
    return Material(
      color: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xEE101614),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: green, width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'RutaViva',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
                GestureDetector(
                  onTap: () => FlutterOverlayWindow.closeOverlay(),
                  child: const Icon(Icons.close, color: Colors.white70, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('Neto hoy: ${_m(net)}',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            Text('${_m(perHour)} por hora',
                style: const TextStyle(color: Colors.white, fontSize: 13)),
            Text(
              'Km con pasajero ${kmPass.toStringAsFixed(1)} · vacíos ${kmEmpty.toStringAsFixed(1)}',
              style: const TextStyle(color: Colors.white70, fontSize: 12),
            ),
            const SizedBox(height: 6),
            SizedBox(
              height: 34,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: homeMode ? green : Colors.grey.shade800,
                  padding: EdgeInsets.zero,
                ),
                onPressed: () => FlutterOverlayWindow.shareData('toggleHome'),
                child: Text(
                  homeMode ? 'Hacia casa: ACTIVO' : 'Hacia casa',
                  style: const TextStyle(fontSize: 13),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
