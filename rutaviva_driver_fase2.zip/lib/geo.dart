import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

class GeoPoint {
  final double lat;
  final double lon;
  const GeoPoint(this.lat, this.lon);
}

class RouteInfo {
  final double km;
  final double minutes; // sin tráfico
  const RouteInfo(this.km, this.minutes);
}

/// Busca una dirección en El Salvador con Nominatim (OpenStreetMap).
Future<GeoPoint?> geocode(String query) async {
  final q = query.trim();
  if (q.isEmpty) return null;
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'q': '$q, El Salvador',
    'format': 'json',
    'limit': '1',
    'countrycodes': 'sv',
  });
  final res = await http
      .get(uri, headers: {'User-Agent': 'RutaViva/2.0'})
      .timeout(const Duration(seconds: 12));
  if (res.statusCode != 200) return null;
  final list = jsonDecode(res.body) as List;
  if (list.isEmpty) return null;
  final m = list.first as Map<String, dynamic>;
  final lat = double.tryParse('${m['lat']}');
  final lon = double.tryParse('${m['lon']}');
  if (lat == null || lon == null) return null;
  return GeoPoint(lat, lon);
}

/// Distancia y tiempo por carretera con OSRM (sin tráfico).
Future<RouteInfo?> drivingRoute(GeoPoint a, GeoPoint b) async {
  final uri = Uri.parse(
    'https://router.project-osrm.org/route/v1/driving/'
    '${a.lon},${a.lat};${b.lon},${b.lat}?overview=false',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 15));
  if (res.statusCode != 200) return null;
  final j = jsonDecode(res.body) as Map<String, dynamic>;
  final routes = j['routes'] as List?;
  if (routes == null || routes.isEmpty) return null;
  final r = routes.first as Map<String, dynamic>;
  final meters = (r['distance'] as num).toDouble();
  final seconds = (r['duration'] as num).toDouble();
  return RouteInfo(meters / 1000, seconds / 60);
}

double haversineKm(GeoPoint a, GeoPoint b) {
  const r = 6371.0;
  double rad(double d) => d * pi / 180;
  final dLat = rad(b.lat - a.lat);
  final dLon = rad(b.lon - a.lon);
  final h = pow(sin(dLat / 2), 2) +
      cos(rad(a.lat)) * cos(rad(b.lat)) * pow(sin(dLon / 2), 2);
  return 2 * r * asin(sqrt(h));
}
