# RutaViva Driver (fase 3)

Calculadora de rentabilidad para conductores de inDrive/Uber/Yango.

## Cómo obtener la APK (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido de esta carpeta** (incluida la carpeta oculta `.github`).
3. Entra a la pestaña **Actions** → **Build APK** → se ejecuta solo (o pulsa *Run workflow*).
4. Al terminar (5–10 min), abre la ejecución y descarga el artefacto **rutaviva-apk**.
5. Descomprime e instala `app-release.apk` en tu Android (permite "instalar apps desconocidas").

## Qué incluye esta fase

- Onboarding: vehículo, meta diaria
- Calculadora con veredicto CONVIENE / DUDOSO / NO CONVIENE
- Registro de viajes ("Acepté este viaje") y cierre con gasto real
- Dashboard diario y de 7 días con insights básicos
- Pasajeros y zonas marcados (solo en el teléfono) con aviso en la calculadora
- Alertas locales de 2 horas con votación
- Plan gratis (10 cálculos/día) y Premium en modo prueba
- Mapa de calor de ejemplo (datos simulados)

## Novedades de la fase 2

- **Leer captura de inDrive**: eliges la captura de la galería y la app lee precio, km y minutos (ML Kit, funciona sin internet). Siempre revisa los valores: si la captura muestra recogida y viaje, toma el km y los minutos mayores.
- **Distancia automática**: escribe origen y destino (colonia y municipio) y la app calcula km y tiempo por carretera con OpenStreetMap/OSRM (gratis, sin clave). El tiempo se multiplica por el factor de tráfico de Ajustes (por defecto ×1.3).
- **Modo flotante**: interruptor en Inicio. Pide el permiso "Mostrar sobre otras apps" y muestra una burbuja arrastrable con neto de hoy, \$/hora, km con pasajero / vacíos y el botón **Hacia casa**.
- **Hacia casa**: guarda tu casa en Ajustes. Con el botón activo, cada cálculo te dice si el destino queda a 5 km o menos de tu casa (en línea recta). Hace falta usar "Distancia automática" para conocer el destino.

## Novedades de la fase 3

- **Mapa** (pestaña nueva): OpenStreetMap con zonas de ejemplo coloreadas por \$/km, tu casa y el botón "Mi ubicación" (GPS).
- **Ruta en el mapa**: al usar "Distancia automática" se dibuja la ruta en la calculadora y en el resultado.
- **Usar mi ubicación como origen**: icono de GPS en el campo Origen.
- **Diseño más dinámico**: animaciones de entrada, contador de ganancia, anillo de meta diaria, botón que respira, veredicto animado con barra de \$/hora.
- **Pasajeros y zonas** pasó a Ajustes.

## Pendiente para las siguientes fases

- Mapa de calor real y alertas compartidas (Firebase)
- Pagos de Premium, exportar a Excel, anuncios

## Fórmula usada

- Km recorridos = distancia (×2 si cuentas regreso vacío)
- Combustible = km recorridos / km por galón × precio del galón
- Neto = precio − combustible − 15% comisión − \$0.03 × km recorridos
- \$/hora = neto / horas (el tiempo también se duplica con regreso vacío)
- CONVIENE si > \$4/h, NO CONVIENE si < \$2/h (o neto negativo), DUDOSO en medio
