"""Agrega permisos y el servicio de la burbuja flotante al AndroidManifest generado."""
import sys

path = sys.argv[1]
xml = open(path, encoding="utf-8").read()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>
"""

service = """        <service
            android:name="flutter.overlay.window.flutter_overlay_window.OverlayService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Burbuja flotante con la ganancia del conductor"/>
        </service>
"""

if "SYSTEM_ALERT_WINDOW" not in xml:
    xml = xml.replace("<application", perms + "    <application", 1)
if "OverlayService" not in xml:
    xml = xml.replace("</application>", service + "    </application>", 1)

open(path, "w", encoding="utf-8").write(xml)
print("Manifest parchado")
